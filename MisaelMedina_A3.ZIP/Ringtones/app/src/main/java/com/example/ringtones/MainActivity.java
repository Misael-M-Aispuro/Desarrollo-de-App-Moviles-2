package com.example.ringtones;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        TextView audiotextView = findViewById(R.id.audiotextView);
        ImageView logoimageview = findViewById(R.id.logoimageview);


        Animation animacionSubir = AnimationUtils.loadAnimation(this, R.anim.desplazamiento_arriba);

        logoimageview.startAnimation(animacionSubir);
        audiotextView.startAnimation(animacionSubir);

        /*
           DESPLAZAMIENTO ABAJO
           logoimageview.startAnimation(animacionBajar);
           audiotextView.startAnimation(animacionSubir);
        */


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
               Intent intent = new Intent(MainActivity.this, ViewActivity.class);
                startActivity(intent);
                    finish();
            }
        }, 4000);
    }
}