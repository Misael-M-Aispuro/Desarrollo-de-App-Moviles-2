package com.example.ringtones;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.SharedPreferences;

public class ShareActivity extends AppCompatActivity {

    Button face, twit, insta, wsp, back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_share);

        View rootLayout = findViewById(R.id.main);
        if (rootLayout != null) {
            ViewCompat.setOnApplyWindowInsetsListener(rootLayout, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        face = findViewById(R.id.face);
        twit = findViewById(R.id.twit);
        insta = findViewById(R.id.insta);
        wsp = findViewById(R.id.wsp);
        back = findViewById(R.id.back);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShareActivity.this, ViewActivity.class);
                startActivity(intent);
                //finish(); //
            }
        });

        face.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Encuentra los mejores sonidos en http://www.sonidosmp3gratis.com/");

                try {
                    share.setPackage("com.facebook.katana");
                    startActivity(share);
                    sumarPuntoYNotificar();
                } catch (Exception e) {

                    startActivity(Intent.createChooser(share, "Compartir con:"));
                    sumarPuntoYNotificar();
                }
            }
        });

        wsp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Encuentra los mejores sonidos en http://www.sonidosmp3gratis.com/");

                try {
                    share.setPackage("com.whatsapp");
                    startActivity(share);
                    sumarPuntoYNotificar();
                } catch (Exception e) {

                    startActivity(Intent.createChooser(share, "Compartir con:"));
                    sumarPuntoYNotificar();
                }
            }
        });

        twit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Encuentra los mejores sonidos en http://www.sonidosmp3gratis.com/");

                try {
                    share.setPackage("com.twitter.android");
                    startActivity(share);
                    sumarPuntoYNotificar();
                } catch (Exception e) {

                    startActivity(Intent.createChooser(share, "Compartir con:"));
                    sumarPuntoYNotificar();
                }
            }
        });

        insta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Encuentra los mejores sonidos en http://www.sonidosmp3gratis.com/");

                try {
                    share.setPackage("com.instagram");
                    startActivity(share);
                    sumarPuntoYNotificar();
                } catch (Exception e) {

                    startActivity(Intent.createChooser(share, "Compartir con:"));
                    sumarPuntoYNotificar();
                }
            }
        });

    }

    private void sumarPuntoYNotificar() {

        android.content.SharedPreferences prefs = getSharedPreferences("MisPuntos", MODE_PRIVATE);
        int puntosActuales = prefs.getInt("puntos", 0);


        puntosActuales++;


        android.content.SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("puntos", puntosActuales);
        editor.apply();


        android.widget.Toast.makeText(this,
                "¡Punto ganado! Tienes: " + puntosActuales + " puntos",
                android.widget.Toast.LENGTH_SHORT).show();
    }





}