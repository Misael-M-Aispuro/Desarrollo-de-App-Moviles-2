package com.example.ringtones;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;




public class ViewActivity extends AppCompatActivity {

    Button play1, play2, play3, play4, play5, share1, share2, share3, share4, share5, blue1, blue2, blue3, blue4, blue5;

    MediaPlayer mp1, mp2, mp3, mp4, mp5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_view);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        setContentView(R.layout.activity_view);
        play1 = (Button) findViewById(R.id.play1);
        play2 = (Button) findViewById(R.id.play2);
        play3 = (Button) findViewById(R.id.play3);
        play4 = (Button) findViewById(R.id.play4);
        play5 = (Button) findViewById(R.id.play5);

        share1 = (Button) findViewById(R.id.share1);
        share2 = (Button) findViewById(R.id.share2);
        share3 = (Button) findViewById(R.id.share3);
        share4 = (Button) findViewById(R.id.share4);
        share5 = (Button) findViewById(R.id.share5);

        blue1 = (Button) findViewById(R.id.blue1);
        blue2 = (Button) findViewById(R.id.blue2);
        blue3 = (Button) findViewById(R.id.blue3);
        blue4 = (Button) findViewById(R.id.blue4);
        blue5 = (Button) findViewById(R.id.blue5);

        mp1 = MediaPlayer.create(this, R.raw.ringtonespinkpanther);
        mp2 = MediaPlayer.create(this, R.raw.ringtonesgoodbadandugly);
        mp3 = MediaPlayer.create(this, R.raw.dragonball);
        mp4 = MediaPlayer.create(this, R.raw.correcaminosbipbip);
        mp5 = MediaPlayer.create(this, R.raw.yoshiowowowow);

        play1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mp1.isPlaying()) {
                    mp1.pause();
                    Toast.makeText(ViewActivity.this, "Pausado", Toast.LENGTH_SHORT).show();
                } else {
                    mp1.start();
                    Toast.makeText(ViewActivity.this, "Reproduciendo", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mp2.isPlaying()) {
                    mp2.pause();
                    Toast.makeText(ViewActivity.this, "Pausado", Toast.LENGTH_SHORT).show();
                } else {
                    mp2.start();
                    Toast.makeText(ViewActivity.this, "Reproduciendo", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mp3.isPlaying()) {
                    mp3.pause();
                    Toast.makeText(ViewActivity.this, "Pausado", Toast.LENGTH_SHORT).show();
                } else {
                    mp3.start();
                    Toast.makeText(ViewActivity.this, "Reproduciendo", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mp4.isPlaying()) {
                    mp4.pause();
                    Toast.makeText(ViewActivity.this, "Pausado", Toast.LENGTH_SHORT).show();
                } else {
                    mp4.start();
                    Toast.makeText(ViewActivity.this, "Reproduciendo", Toast.LENGTH_SHORT).show();
                }
            }
        });

        play5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mp5.isPlaying()) {
                    mp5.pause();
                    Toast.makeText(ViewActivity.this, "Pausado", Toast.LENGTH_SHORT).show();
                } else {
                    mp5.start();
                    Toast.makeText(ViewActivity.this, "Reproduciendo", Toast.LENGTH_SHORT).show();
                }
            }
        });


        share1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewActivity.this, ShareActivity.class);
                startActivity(intent);
            }
        });

        share2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewActivity.this, ShareActivity.class);
                startActivity(intent);
            }
        });

        share3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewActivity.this, ShareActivity.class);
                startActivity(intent);
            }
        });

        share4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewActivity.this, ShareActivity.class);
                startActivity(intent);
            }
        });

        share5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewActivity.this, ShareActivity.class);
                startActivity(intent);
            }
        });

        blue1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("audio/mp3");

                Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.ringtonespinkpanther);

                intent.putExtra(Intent.EXTRA_STREAM, uri);

                startActivity(Intent.createChooser(intent, "Compartir con..."));
            }
        });

        blue2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("audio/mp3");

                Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.ringtonesgoodbadandugly);

                intent.putExtra(Intent.EXTRA_STREAM, uri);

                startActivity(Intent.createChooser(intent, "Compartir con..."));
            }
        });

        blue3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("audio/mp3");

                Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.dragonball);

                intent.putExtra(Intent.EXTRA_STREAM, uri);

                startActivity(Intent.createChooser(intent, "Compartir con..."));
            }
        });

        blue4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("audio/mp3");

                Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.correcaminosbipbip);

                intent.putExtra(Intent.EXTRA_STREAM, uri);

                startActivity(Intent.createChooser(intent, "Compartir con..."));
            }
        });

        blue5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("audio/mp3");

                Uri uri = Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.yoshiowowowow);

                intent.putExtra(Intent.EXTRA_STREAM, uri);

                startActivity(Intent.createChooser(intent, "Compartir con..."));
            }
        });

    }
}





