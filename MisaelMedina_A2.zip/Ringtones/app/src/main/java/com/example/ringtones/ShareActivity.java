package com.example.ringtones;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ShareActivity extends AppCompatActivity {

    Button face, twit, insta, wsp, back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_share);

        View rootLayout = findViewById(R.id.main);
        if (rootLayout != null) {
            ViewCompat.setOnApplyWindowInsetsListener(rootLayout, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        face = findViewById(R.id.face);
        twit = findViewById(R.id.twit);
        insta = findViewById(R.id.insta);
        wsp = findViewById(R.id.wsp);
        back = findViewById(R.id.back);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ShareActivity.this, ViewActivity.class);
                startActivity(intent);
                //finish(); //
            }
        });

        face.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Encuentra los mejores sonidos en http://www.sonidosmp3gratis.com/");

                try {
                    share.setPackage("com.facebook.katana");
                    startActivity(share);
                } catch (Exception e) {

                    startActivity(Intent.createChooser(share, "Compartir con:"));
                }
            }
        });

        wsp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Encuentra los mejores sonidos en http://www.sonidosmp3gratis.com/");

                try {
                    share.setPackage("com.whatsapp");
                    startActivity(share);
                } catch (Exception e) {

                    startActivity(Intent.createChooser(share, "Compartir con:"));
                }
            }
        });

        twit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Encuentra los mejores sonidos en http://www.sonidosmp3gratis.com/");

                try {
                    share.setPackage("com.twitter.android");
                    startActivity(share);
                } catch (Exception e) {

                    startActivity(Intent.createChooser(share, "Compartir con:"));
                }
            }
        });

        insta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, "Encuentra los mejores sonidos en http://www.sonidosmp3gratis.com/");

                try {
                    share.setPackage("com.instagram");
                    startActivity(share);
                } catch (Exception e) {

                    startActivity(Intent.createChooser(share, "Compartir con:"));
                }
            }
        });




    }
}